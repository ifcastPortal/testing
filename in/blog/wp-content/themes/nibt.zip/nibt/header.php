<!DOCTYPE html>
<html <?php language_attributes(); ?>>
    
<head>
	<?php  wp_head();  ?>
    <title><?php bloginfo('title'); ?></title>
    <!-- Required meta tags -->
     <meta charset="<?php bloginfo( 'charset' ); ?>">
     <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="fb:pages" content="1640353259591474" />
    <meta name="google-site-verification" content="t3fAoJzBtca5oyx9xjbDblzAIy3MbmHSMDmJGxB32Iw" />

    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/bootstrap-carousel.css">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/font-awesome.min.css">
    
    <!-- ElegantFonts CSS -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/elegant-fonts.css">
    
    <!-- themify-icons CSS -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/themify-icons.css">
    
     <!-- Slider -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/themes/js-image-slider.css"  type="text/css" />


    <!-- Swiper CSS -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/swiper.min.css">
    
    <!-- Custom styles for this template -->
    <link href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/starter-template.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:400,200,900italic,900,700italic,700,600italic,600,400italic,300italic,300,200italic">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/style.css">
    <link rel="stylesheet" href="<?php bloginfo('stylesheet_directory'); ?>/assets/css/animate.css">     
    <script src="<?php bloginfo('stylesheet_directory'); ?>/assets/js/wow.min.js"></script>
      <script>
      new WOW().init();
      </script>
    <link rel="icon" href="<?php bloginfo('stylesheet_directory'); ?>/assets/images/favicon.png" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript">

		// Ajax post
	$(document).ready(function() {
	 $(".getsubscribe").click(function(event) {
	 	$("p#message_sub").empty();
	    $("p#Email_sub").empty();
	    $("p#Phone_sub").empty();
		event.preventDefault();
		$("#process-loader2").show();
		var userEmail = $("input#Email_subsc").val();
		var userPhone = $("input#Phone_subsc").val();
		jQuery.ajax({
		type: "POST",
		url: "https://nibt.education/getSubscriber",
		dataType: "json",
		data: {userEmail: userEmail, userPhone: userPhone},
		success: function(data)             // A function to be called if request succeeds
			{
			$.each(data, function(index, element) {
			        $("p#Email_sub").append(element.userEmail);
			        $("p#Phone_sub").append(element.userPhone);	
					$("p#message_sub").append(element.err);	
					$("p#message_sub").append(element.succes);
					if(element.succes != null){
						document.getElementById("getsubscribe").reset();
					}
					$("#process-loader2").hide();
			    });  
			}  
		});
	  });
	});
	</script>
<!--Start of Tawk.to Script-->
<script >
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5a151deebb0c3f433d4ca8d8/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-123494557-1"></script>
    
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-123494557-1');
</script>

<!-- Facebook Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window,document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
 fbq('init', '309311249483867'); 
fbq('track', 'PageView');
</script>
<noscript>
 <img height="1" width="1" 
src="https://www.facebook.com/tr?id=309311249483867&ev=PageView
&noscript=1"/>
</noscript>
<!-- End Facebook Pixel Code -->

</head>
<body>
<a id="back2Top" title="Back to top" href="#">&#10148;</a>

<header class="site-header">
    <div class="nav-bar" >
        <div class="container" >
            <div class="row" >
                <div class="col-10 col-lg-2 col-md-10 " >
                    <div class="site-branding">
                        <h1 class="site-title"> <a href="https://nibt.education/"><img src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/head-logo.png" alt=""></a></h1>
                    </div><!-- .site-branding -->
                </div><!-- .col -->
                <div class="col-2 col-lg-5 col-md-2 flex nav-main-new-width"  >
                    <nav class="site-navigation flex justify-content-end align-items-center" style="width: 100%;">
                        <ul class="flex flex-column flex-lg-row ">
                            <li class=""><a href="https://nibt.education/classroom">Classroom</a></li>
                            <li class=""><a href="https://nibt.education/elearning/">e-Learning</a></li>
                            <li class=""><a href="https://nibt.education/virtual-class/">Virtual Classes</a></li>
                            <li class=""><a href="https://nibt.education/nibt-talk/">NIBT Talk</a></li>
                            <li class=""><a href="https://nibt.education/corporate/">Corporate</a></li>
                        </ul>
                        
                        <div class="hamburger-menu d-lg-none">
                            <span></span>
                            <span></span>
                            <span></span>
                            <span></span>
                        </div><!-- .hamburger-menu -->
                    </nav><!-- .site-navigation -->
                </div>
                
                 <div class="col-12 col-lg-3 col-md-9 col-sm-9" >
                    <!-- .site-navigation -->
                     <div class="header-bar-search margin-adjust" >
                             <form class="flex align-items-stretch" action="https://nibt.education/search-result" method="post">
                                 <input required name="keyword" type="text" placeholder="Search" class="bg-gray mr-10" style="margin-right:10px;">
                                 <button type="submit" name='submit' value='Submit' class="flex justify-content-center align-items-center" style="margin-top:12px;"><i class="fa fa-search" ></i></button>
                             </form>
                     </div>
                </div>
                <div class="col-12 col-lg-2 col-md-3 col-sm-3 flex justify-content-end "  >
                    <nav class="site-navigation-two flex " style="width: 100%;">
                        
                      
                    </nav><!-- .site-navigation -->
                </div>

                <!-- .col -->
            </div><!-- .row -->
        </div><!-- .container -->
    </div><!-- .nav-bar -->
</header><!-- .site-header -->