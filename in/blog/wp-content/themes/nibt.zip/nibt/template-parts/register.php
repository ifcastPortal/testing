<?php
/**
 * Template part for register page
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package NIBT
 */

?>
<div class="col-md-8 col-md-offset-2">
    <div class="register-box text-center">
		<div class="panel">
			<div class="panel-body">
				<?php the_content(); ?>				
			</div>
		</div>
	</div>
</div>
