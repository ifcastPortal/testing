<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package NIBT
 */

?>

<div class="media"> 
  <div class="media-left"> 
    <a href="#"> 
      <img alt="" class="media-object" src="images/news1.jpg" data-holder-rendered="true"> 
    </a> 
  </div>
  <div class="media-body"> 
      <h4 class="media-heading"><a href="#">Media heading</a></h4> 
  </div> 
</div>