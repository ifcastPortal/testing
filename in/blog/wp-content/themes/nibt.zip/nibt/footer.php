<!-- START SUBSCRIBE SECTION -->
        <section class="container subscribe-section">
            <div class="row">   
                <div class="col-12">
                    <h1 class="section-title  white">Subscribe &amp; Get Ready</h1>
                     <p>Grasp The Futuristic World of Construction and advance your skills.</p>
                     <p id="message_sub"></p>               
                     <img style="text-align: center;display: none;margin: auto;" width="30" src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/process-loader.gif" id="process-loader2" />
                </div>
            </div>
            
            <form name="getsubscribe" id="getsubscribe" action="" method="post">
                <div class="row">
                    <div class="col-12 col-lg-5 col-md-6 col-sm-12">
                        <input type="text" name="Phone_subsc" id="Phone_subsc" placeholder="Phone">
                        <p id="Phone_sub" style="color: #FFF;"></p> 
                        
                    </div>
                
                    <div class="col-12 col-lg-5 col-md-6 col-sm-12">
                        <input type="email" name="Email_subsc" id="Email_subsc" placeholder="Email">
                        <p id="Email_sub" style="color: #FFF;"></p> 
                    </div>
                
                    <div class="col-5 offset-4 col-lg-2 col-md-2 offset-lg-0 offset-md-4  col-sm-2 offset-sm-4">
                        <button  class="nibt-btn-blue getsubscribe" type="button" value="" >SUBSCRIBE</button>
                    </div>
                </div>
            </form>
        </section>
        <!-- END SUBSCRIBE SECTION -->
        
        <!-- START FOOTER SECTION -->
        <footer class="site-footer">
            <div class="footer-widgets">
                <div class="container">
                    <div class="row">
                        <div class="col-12 col-md-6 col-lg-3">
                            <div class="foot-about">
                                <a class="foot-logo" href="#"><img src="<?php bloginfo('stylesheet_directory'); ?>/assets/images/foot-logo.png" alt=""></a>
                                <p>At NIBT, we deliver comprehensive courses and modules integrated with modern technology for BIM & GIS. Focused learning through a simple & easy to use learning interface, highly trained professionals and industry experts. </p>
                               
                            </div><!-- .foot-about -->
                        </div><!-- .col -->

                        <div class="col-12 col-md-6 col-lg-3 mt-5 mt-md-0">
                            <div class="foot-contact">
                                <h2>Contact Us</h2>
                                <ul>
                                    <li>Email: info@nibt.education</li>
                                    <li>Phone: +91 73502 55855</li>
                                    <li>Address: Dattashri, Near Hotel Riviera, ABB Circle, Mahatma Nagar, Nashik, Maharashtra 422005</li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-12 col-md-6 col-lg-3 mt-5 mt-lg-0">
                           <div class="foot-contact">
                                <h2 >Quick Links</h2>
                                <ul >
                                    <li><a href="https://nibt.education/aboutus">About Us</a></li>
                                    <li><a href="https://nibt.education/contact-us#centers" class="scroll-link" data-id="centers">Our Centers </a></li>                      
                                    <li><a href="https://nibt.education/terms">Terms of Use </a></li>
                                    <li><a href="https://nibt.education/privacy-policy">Privacy Policy </a></li>
                                    <li><a href="https://nibt.education/faq">FAQs </a></li>
                                    <li><a href="https://nibt.education/contact-us">Contact Us</a></li>
                                </ul>

                               <!-- <ul class="w-50">
                                    <li><a href="#">Documentation</a></li>
                                    <li><a href="#">Forums</a></li>
                                    <li><a href="#">Language Packs</a></li>
                                    <li><a href="#">Release Status</a></li>
                                </ul>-->
                            </div><!-- .quick-links -->
                        </div><!-- .col -->

                        <div class="col-12 col-md-6 col-lg-3 mt-5 mt-lg-0">
                            <div class="follow-us">
                                <h2>Follow Us</h2>
                                <ul class="follow-us flex flex-wrap align-items-center">
                                   <a target="_blank" href="https://www.linkedin.com/in/nibt-education/"><li><i class="fa fa-linkedin"></i></li></a>
                                   <a target="_blank" href="https://www.facebook.com/nibtindia"><li><i class="fa fa-facebook"></i></li></a>
                                    <a target="_blank" href="https://plus.google.com/+NationalInstituteofBuildingTechnology"><li><i class="fa fa-google-plus"></i></li></a>
                                    <a target="_blank" href="https://www.instagram.com/nibteducation_/"><li><i class="fa fa-instagram"></i></li></a>
                                    <a target="_blank" href="https://twitter.com/NIBTEducation"><li><i class="fa fa-twitter"></i></li></a>
                                    
                                </ul>
                            </div><!-- .quick-links -->
                        </div><!-- .col -->
                    </div><!-- .row -->
                </div><!-- .container -->
            </div><!-- .footer-widgets -->
            <div class="footer-bar">
                <div class="container">
                    <div class="row flex-wrap justify-content-center justify-content-lg-between align-items-center">

                         <p class="footer-copyright">
                                    Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved<a href="https://nibt.education" target="_blank">&nbsp;&nbsp;NIBT</a>
                                </p>
                        
                        
                        
                    </div>
                </div>
            </div><!-- .footer-bar -->
        </footer><!-- .site-footer -->
        <!-- END FOOTER SECTION -->
        
        
        <!-- START FOOTER SECTION -->
        <script>
    
	    $(window).scroll(function() {
	    var height = $(window).scrollTop();
	    if (height > 100) {
	        $('#back2Top').fadeIn();
	    } else {
	        $('#back2Top').fadeOut();
	    }
	});
	$(document).ready(function() {
	    $("#back2Top").click(function(event) {
	        event.preventDefault();
	        $("html, body").animate({ scrollTop: 0 }, "slow");
	        return false;
	    });
	
	});
	    
  
	 /*Scroll to top when arrow up clicked END*/
	</script>
        <!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>-->
        <script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/assets/js/jquery.js'></script>
        <script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/assets/js/swiper.min.js'></script>
        <script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/assets/js/masonry.pkgd.min.js'></script>
        <script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/assets/js/jquery.collapsible.min.js'></script>
        <script type='text/javascript' src='<?php bloginfo('stylesheet_directory'); ?>/assets/js/custom.js'></script>
         <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<?php wp_footer(); ?>
    </body>
    
</html>
